from app.routes.character import router as character_router
